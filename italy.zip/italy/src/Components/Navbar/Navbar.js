import React, { useState } from "react";
import styled from "styled-components";
import { Row, Col } from "react-bootstrap";
import { GiHamburgerMenu } from "react-icons/gi";
import { Link } from "react-router-dom";

const Wrapper = styled.div`
  top: 0;
  left: 0;
  width: 100%;

  padding: 15px 40px;
  background: #000;
  color: #fff;

  .nav-heading {
    margin: 0;
    font-family: "Asap", sans-serif;
    font-style: normal;
    font-weight: normal;
    font-size: 25px;
    line-height: 29px;

    color: #ffffff;
  }
  .nav-container {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }
  .nav-subheading {
    margin: 0;
    font-size: 14px;
  }
  .link {
    margin: 0;
    font-size: 18px;
  }
  .booking {
    margin-right: 40px;
  }
  .mobile {
    position: relative;
  }
  .nav-container {
    background: #000;
    position: absolute;
    padding: 20px;
    top: 50px;
    right: 0px;
    border-radius: 7px;
  }
  a {
    text-decoration: none;
    color: #fff;
  }
  @media only screen and (max-width: 767px) {
    padding: 12px 20px;
    .dekstop {
      display: none;
    }
    .mobile {
      display: block;
    }
    .nav-heading {
      font-size: 25px;
    }
    .nav-subheading {
      font-size: 11px;
    }
  }
`;
const Navbar = () => {
  const [dropdown, setDropDown] = useState(false);
  return (
    <Wrapper>
      <Row className="d-flex justify-content-center align-items-center">
        <Col xs={8} md={4}>
          <Link to="/">
            <h4 className="nav-heading">here2there</h4>
            <p className="nav-subheading">decentralized autonomous driving</p>
          </Link>
        </Col>
        <Col
          md={8}
          className=" d-none d-md-flex align-items-center justify-content-end dekstop "
        >
          <Link to="booking">
            <p className="link booking">Booking</p>
          </Link>
          <Link to="payment">
            <p className="link payment">Payment</p>
          </Link>
        </Col>
        <Col
          xs={4}
          className="d-flex align-items-center  justify-content-end mobile d-md-none"
        >
          <GiHamburgerMenu
            size={25}
            onClick={() => setDropDown((prev) => !prev)}
          />
          {dropdown && (
            <div className="nav-container">
              <Link to="booking">
                <p className="link py-2" onClick={() => setDropDown(false)}>
                  Booking
                </p>
              </Link>
              <Link to="payment">
                <p className="link  py-2" onClick={() => setDropDown(false)}>
                  Payment
                </p>
              </Link>
            </div>
          )}
        </Col>
      </Row>
    </Wrapper>
  );
};
export default Navbar;
