import React from "react";
import styled from "styled-components";
import { Row, Col } from "react-bootstrap";
import card2 from "../../images/card2.svg";

const Wrapper = styled.div`
  overflow: hidden;

  color: #fff;

  .booking {
    height: 100vh !important;
  }
  .text {
    background: #1a1f22;
    padidng: 15px;
    padding-top: 8%;
  }
  .image {
    width: 100%;
    height: 100%;
  }
  img {
    object-fit: cover;
    object-position: center;
  }
  .list-container {
    width: 50%;
  }
  .list {
    color: #87bcbc;
  }
  .first {
    padding-top: 50px;
  }
  @media only screen and (max-width: 991px) {
    .list-container {
      width: 80%;
    }
  }
  @media only screen and (max-width: 615px) {
    .list-container {
      width: 90%;
    }
  }
  @media only screen and (max-width: 480px) {
    .list-container {
      width: 95%;
    }
    .message {
      font-size: 13px;
    }
  }

  @media only screen and (max-width: 465px) {
    .list-head {
      font-size: 13px;
    }
    .list {
      font-size: 14px;
    }
    .list h6 {
      font-size: 13px;
    }
  }
`;
const Booking = () => {
  return (
    <Wrapper>
      <Row className="booking">
        <Col
          xs={9}
          sm={8}
          md={8}
          className="d-flex flex-column text  align-items-center text-center "
        >
          <div className="list-container">
            <Col xs={12}>
              <Row>
                <Col xs={6}>
                  <h5 className="list-head">Select Departure</h5>
                </Col>
                <Col xs={6}>
                  <h5 className="list ">
                    Roma Termini <br /> <h6>Pick up Station 1</h6>
                  </h5>
                  <h5 className="list py-4">
                    Roma Fiumicino <br /> <h6>Pick up Station 1</h6>
                  </h5>
                </Col>
              </Row>

              <h5 className="message first">
                Take advantage of the Fixed Price
              </h5>

              <h5 className="message">50 euros each way</h5>

              <h5 className="message"> Pay in fiat or crypto</h5>
            </Col>
          </div>
        </Col>
        <Col
          xs={3}
          sm={4}
          md={4}
          className="p-0 m-0"
          style={{ background: "#1a1f22" }}
        >
          <img src={card2} alt="" className="w-100 image" />
        </Col>
      </Row>
    </Wrapper>
  );
};
export default Booking;
