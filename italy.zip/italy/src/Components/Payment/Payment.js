import React, { useState } from "react";
import styled from "styled-components";
import { Row, Col } from "react-bootstrap";
import card3 from "../../images/card3.svg";
import metamask from "../../images/metamask.svg";

const Wrapper = styled.div`
  overflow: hidden;

  color: #fff;
  .modals {
    position: absolute;
    background: rgba(0, 0, 0, 0.9);
    top: 70px;
    color: #fff;
    width: 480px;
    margin: 0 auto;
    height: 300px;
    left: 50%;
    transform: translateX(-50%);
  }
  .payment {
    height: 100vh;
  }
  .text {
    background: #1a1f22;
    padidng: 15px;
    padding-top: 15%;
  }
  .image {
    width: 100%;
    height: 100%;
  }
  img {
    object-fit: cover;
    object-position: center;
  }
  .list-container {
    width: 50%;
  }

  .metamask {
    width: 100px;
    height: 40px;
  }

  .p-head {
    margin: 8px;
  }
  .card-number {
    outline: 0;
    padding: 6px 10px;
    width: 100%;
  }

  .button {
    outline: none;
    border: none;
    padding: 4px 8px;
    position: absolute;
    bottom: 20px;
    right: 20px;
    font-weight: 700;
  }
  .crypto {
    font-size: 25px;
    padding-top: 60px;
  }
  @media only screen and (max-width: 991px) {
    .list-container {
      width: 80%;
    }
  }
  @media only screen and (max-width: 767px) {
    .crypto {
      font-size: 25px;
      padding-top: 35px;
    }
  }
  @media only screen and (max-width: 615px) {
    .list-container {
      width: 90%;
    }
    .modals h5 {
      font-size: 14px;
    }
    .modals {
      width: 100%;
    }
  }
  @media only screen and (max-width: 480px) {
    .list-container {
      width: 95%;
    }
    .message {
      font-size: 13px;
    }
  }

  @media only screen and (max-width: 465px) {
    .list-head {
      font-size: 13px;
    }
  }
`;
const Booking = () => {
  const [modal, setModal] = useState(false);
  return (
    <Wrapper>
      <Row className="payment">
        <Col
          xs={9}
          sm={8}
          md={8}
          className="d-flex flex-column text  align-items-center text-center "
        >
          <div className="list-container">
            <Col xs={12}>
              <Row className="flex-column flex-md-row justify-content-center align-items-center">
                <Col
                  xs={4}
                  className="py-3 py-md-0 d-flex justify-content-center flex-column align-items-center "
                >
                  <p className="p-head"> Crypto</p>
                  <img src={metamask} alt="" className="metamask" />
                </Col>
                <Col
                  xs={11}
                  sm={8}
                  className="py-3 py-md-0 d-flex justify-content-center flex-column  align-items-center"
                >
                  <p className="p-head">Fiat Card Number</p>
                  <input
                    type="text"
                    className="card-number"
                    onKeyUp={(event) => {
                      if (event.keyCode === 13) {
                        event.preventDefault();
                        setModal((prev) => !prev);
                      }
                    }}
                  />
                </Col>
                <h5 className="crypto"> Pay in fiat or crypto</h5>
              </Row>
            </Col>
          </div>
        </Col>
        <Col
          xs={3}
          sm={4}
          md={4}
          className="p-0 m-0"
          style={{ background: "#1a1f22" }}
        >
          <img src={card3} alt="" className="w-100 image" />
        </Col>
      </Row>
      {modal && (
        <div className="modals">
          <div
            className="w-100  text-center d-flex flex-column align-items-center justify-content-center"
            style={{ height: "100%", position: "relative" }}
          >
            <h5 className="">Payment Confirmed</h5>

            <h5>
              {" "}
              Please head to the Terminal and unlock the first <br /> H2T car in
              line{" "}
            </h5>

            <button className="button" onClick={() => setModal(false)}>
              ok
            </button>
          </div>
        </div>
      )}
    </Wrapper>
  );
};
export default Booking;
