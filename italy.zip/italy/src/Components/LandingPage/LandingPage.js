import React from "react";
import styled from "styled-components";
import { Row, Col } from "react-bootstrap";
import card1 from "../../images/card1.svg";
import metamask from "../../images/metamask.svg";

const Wrapper = styled.div`
  overflow: hidden;

  color: #fff;

  .landingpage {
    height: 100vh !important;
  }
  .text {
    background: #1a1f22;
    padidng: 15px;
  }
  .image {
    width: 100%;
    height: 100%;
  }
  img {
    object-fit: cover;
    object-position: center;
  }
  .l-heading {
    width: 90%;
    font-size: 44px;
    padding-bottom: 15px;
  }
  .metamask {
    width: 170px;
  }
  @media only screen and (max-width: 1199px) {
    .l-heading {
      width: 90%;
      font-size: 35px;
      padding-bottom: 12px;
    }
    .l-subheading {
      font-size: 14px;
    }
    .metamask {
      width: 150px;
    }
  }
  @media only screen and (max-width: 991px) {
    .l-heading {
      width: 90%;
      font-size: 30px;
      padding-bottom: 10px;
    }
    .l-subheading {
      font-size: 13px;
    }
    .metamask {
      width: 140px;
    }
  }
  @media only screen and (max-width: 767px) {
    .l-heading {
      width: 90%;
      font-size: 30px;
      padding-bottom: 10px;
    }
    .l-subheading {
      font-size: 13px;
    }
    .metamask {
      width: 120px;
    }
  }
  @media only screen and (max-width: 576px) {
    .l-heading {
      width: 95%;
      font-size: 25px;
      padding-bottom: 10px;
    }
    .l-subheading {
      font-size: 12px;
    }
    .metamask {
      width: 100px;
    }
  }
  @media only screen and (max-width: 500px) {
    .l-heading {
      width: 90%;
      font-size: 18px;
      padidng: 15px;
      padding-bottom: 10px;
    }
    .l-subheading {
      font-size: 11px;
    }
    .metamask {
      width: 70px;
    }
  }
`;
const LandingPage = () => {
  return (
    <Wrapper>
      <Row className="landingpage">
        <Col
          xs={9}
          sm={8}
          md={8}
          className="d-flex flex-column text justify-content-center align-items-center text-center "
        >
          <h1 className="l-heading">
            With H2T autonomous vehicle you reach Rome city center in the
            fastest way possible
          </h1>
          <p className="l-subheading"> Connect with your wallet</p>
          <img src={metamask} alt="" className="metamask" />
        </Col>
        <Col
          xs={3}
          sm={4}
          md={4}
          className="p-0 m-0"
          style={{ background: "#1a1f22" }}
        >
          <img src={card1} alt="" className="w-100 image" />
        </Col>
      </Row>
    </Wrapper>
  );
};
export default LandingPage;
